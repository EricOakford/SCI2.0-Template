;;; Sierra Script 1.0 - (do not remove this comment)
;Combat Framework defines

;Arena Actions (for the 'Skilled' class)
(enum
	ActNone
	ActThrust
	ActSlash
	ActParryUp
	ActParryDown
	ActDodgeLeft
	ActDodgeRight
	ActDuck
	ActLeap
	ActPain	;never used, just a guess
	ActDie
	ActCast
)

;Attack angles (for close combat)
(enum
	AttLeft
	AttRight
	AttStraight
)

;Armor values
(define LEATHER_VALUE 2)
(define CHAIN_VALUE 5)

;Weapon values
(define DAGGER_VALUE 5)
(define SWORD_VALUE 8)
