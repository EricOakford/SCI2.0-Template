;;; Sierra Script 1.0 - (do not remove this comment)
; This is now just a stub for the TRUE and FALSE defines.

(define TRUE 1)
(define FALSE 0)