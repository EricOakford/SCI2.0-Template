;;; Sierra Script 1.0 - (do not remove this comment)
;; CAT.SH
;; header file for mouse follower

(enum -2
	YDOWN		;-2
	XDOWN		;-1
	NODIAG	;zero
	XUP		;1
	YUP		;2
)

(enum 
	SELFONLY	;FALSE=only animate yourself
	DODOITS	;TRUE=execute cast's doits 
)
